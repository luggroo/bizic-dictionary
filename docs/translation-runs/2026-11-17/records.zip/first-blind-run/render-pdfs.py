"""Render archived blind-test answers without changing their translation text."""
from pathlib import Path
import html,json,re,hashlib
ROOT=Path(__file__).resolve().parent
NAMES={'en-crow':'乌鸦喝水','zh-rabbit':'守株待兔','ja-jizo':'笠地蔵','bo-crane':'洁白的仙鹤','reverse-song':'四行土家语歌'}
STYLE='''@page{size:A4;margin:18mm 17mm 20mm}body{font-family:"DejaVu Sans","Noto Sans CJK SC","Noto Serif Tibetan",sans-serif;font-size:10.5pt;line-height:1.75;color:#20352f}h1{font-size:22pt}h2{font-size:16pt}h3{font-size:12pt}p{margin:0 0 8pt}pre{font-family:inherit;white-space:pre-wrap;overflow-wrap:anywhere;font-size:10pt}.case{break-before:page}h1,h2,h3{break-after:avoid}.meta{font-size:9pt;color:#56645d}.source{background:#f3f5f1;padding:10pt;white-space:pre-wrap}a{color:#215b4a}.block{white-space:pre-wrap;overflow-wrap:anywhere}table{border-collapse:collapse;width:100%;font-size:9pt;table-layout:fixed}td,th{border:0.6pt solid #cbd6d0;padding:5pt;overflow-wrap:anywhere;vertical-align:top}tr{break-inside:avoid}td:last-child,th:last-child{width:48%}'''
def md(s):
    out=[];fenced=False;table=False
    for line in s.splitlines():
        if line.startswith('|') and line.endswith('|'):
            if re.fullmatch(r'[| :\-]+', line):continue
            tag='td' if table else 'th'
            if not table:out.append('<table>');table=True
            out.append('<tr>'+''.join('<'+tag+'>'+html.escape(cell.strip())+'</'+tag+'>' for cell in line.strip('|').split('|'))+'</tr>');continue
        if table:out.append('</table>');table=False
        if line.startswith('```'):
            out.append('</pre>' if fenced else '<pre>');fenced=not fenced;continue
        safe=html.escape(line)
        if fenced:out.append(safe+'\n');continue
        m=re.match(r'^(#{1,6})\s+(.*)',line)
        if m:
            level=min(len(m[1])+1,4);out.append(f'<h{level}>'+html.escape(m[2])+f'</h{level}>')
        elif line.strip():out.append('<p class="block">'+safe+'</p>')
    if table:out.append('</table>')
    if fenced:out.append('</pre>')
    return '\n'.join(out)
def document(body):return '<!doctype html><html lang="zh"><meta charset="utf-8"><style>'+STYLE+'</style><body>'+body+'</body></html>'
def print_pdf(stem,body):
    dest=ROOT/'pdf';dest.mkdir(exist_ok=True);page=dest/(stem+'.html');pdf=page.with_suffix('.pdf')
    rendered=document(body)
    if page.exists() and page.read_text()==rendered and pdf.exists():
        return {'file':str(pdf.relative_to(ROOT)),'sha256':hashlib.sha256(pdf.read_bytes()).hexdigest()}
    page.write_text(rendered)
    from weasyprint import HTML
    HTML(filename=str(page)).write_pdf(str(pdf))
    return {'file':str(pdf.relative_to(ROOT)),'sha256':hashlib.sha256(pdf.read_bytes()).hexdigest()}
if __name__=='__main__':
    cases=json.loads((ROOT/'cases.json').read_text());summary=(ROOT/'review.md').read_text() if (ROOT/'review.md').exists() else '评阅尚未完成。'
    body='<h1>五例独立盲测记录</h1><p class="meta">2026-11-17 · 刚修改的本地 Skill · 静态检索默认路线</p>'+md(summary)
    products=[]
    for c in cases:
        run=ROOT/'runs'/c['id'];first=run/'round1.md'
        if not first.exists():raise FileNotFoundError(first)
        part='<section class="case"><h1>'+NAMES[c['id']]+'</h1><h2>源语言原文</h2><div class="source">'+html.escape(c['source'])+'</div><h2>首轮原始答复</h2>'+md(first.read_text())
        second=run/'round2.md'
        if second.exists():part+='<h2>按标准补查指令所得答复</h2>'+md(second.read_text())
        part+='</section>';body+=part;products.append(print_pdf(c['id'],part))
    products.append(print_pdf('blind-five-report',body))
    (ROOT/'pdf-manifest.json').write_text(json.dumps(products,ensure_ascii=False,indent=2)+'\n');print(json.dumps(products,ensure_ascii=False,indent=2))
