import json, pathlib, unicodedata, sys, datetime
base=pathlib.Path('/workspace/bizic-translator/docs/evaluation/blind-five-2026-11-17')
lex=base/'frozen/skills/translate-tujia/lexicon'; out=base/'runs/bo-crane'
m=json.loads((lex/'manifest.json').read_text()); cache={}
for q in sys.argv[1:]:
 k=unicodedata.normalize('NFKC',q).casefold().strip();h=2166136261
 for b in k.encode():h=((h^b)*16777619)&0xffffffff
 bucket=f'{h>>24:02x}'
 if bucket not in cache:
  cache[bucket]=[json.loads(l) for f in m['buckets'][bucket] for l in (lex/f['path']).read_text().splitlines()]
 hits=[]
 for row in cache[bucket]:
  if row['k']==k:
   d=dict(zip(m['record_fields'],row['r']));d['source_metadata']=m['sources'].get(d['source']);hits.append(d)
 record={'query':q,'engine':'static-exact','revision':m['revision'],'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'hit' if hits else 'zero','results':hits}
 with (out/'queries.jsonl').open('a') as f:f.write(json.dumps(record,ensure_ascii=False)+'\n')
 print(q, len(hits))
 for d in hits[:15]:print(json.dumps(d,ensure_ascii=False))
