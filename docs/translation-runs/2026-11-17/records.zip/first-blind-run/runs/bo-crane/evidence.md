# Evidence and decisions

Started 2026-11-17T15:12:53Z. Ended 2026-11-17T15:16:21.117063+00:00. Frozen manifest and skill hashes are in translation.json. Every executed lexical key and complete response is in queries.jsonl; no embeddings used.

## Source analysis
1. bya de = that bird (vocative/appositional address); khrung khrung dkar po = white crane. First line is an address, not an event assertion.
2. nga la = to me; shog rtsal = wing power/strength; gyor dang = lend/request. Interpret as lending flight-bearing wing strength, not borrowing from speaker. Explicit addressee ni and wing possessor are recovered from context.
3. thag ring rgyang la = into a distant faraway place; mi 'gro = will not go. Scope is intended travel, not inability or prohibition.
4. li thang = Litang; bskor nas = having gone around/made a circuit; slebs yong = come/arrive back. Interpret the line as a proposed trip with return to the speaker’s origin. No romantic or biographical content added.

## Chosen lexical witnesses
- āidī: stedt-rn-455164; brassett-2006; STEDT rn 455164 · 原文定位 7.4
- niébī: stedt-rn-453581; brassett-2006; STEDT rn 453581 · 原文定位 1.3
- ǎsǐ: stedt-rn-454844; brassett-2006; STEDT rn 454844 · 原文定位 6.3
- jiédā: stedt-rn-453564; brassett-2006; STEDT rn 453564 · 原文定位 1.3
- xiēqī: stedt-rn-454794; brassett-2006; STEDT rn 454794 · 原文定位 6.1
- lú: stedt-rn-456952; brassett-2004; STEDT rn 456952 · 原文定位 未标明
- hxě: stedt-rn-456427; brassett-2004; STEDT rn 456427 · 原文定位 未标明
- kō: stedt-rn-454661; brassett-2006; STEDT rn 454661 · 原文定位 5.1
- hxí: stedt-rn-454319; brassett-2006; STEDT rn 454319 · 原文定位 4.3
- sōngkō: stedt-rn-457777; brassett-2004; STEDT rn 457777 · 原文定位 未标明

## Construction support
- clause-patterns.md: ordinary SOV; R bǒ before object (B06:102 ex75); possessive niě (B06:56); goal bō (B06:100 ex64); short property A-nie-N from Feng2025 ex8. Applied to white crane and far place with anchored noun heads.
- directives.md: general request may use bare predicate. No immediate-action gu or obligation do added.
- clause-patterns.md: tā for choice/intention, B06:132 ex172. Third line uses postverbal tā.
- event-linking.md: A-liē-B for completed first event then second; explicitly usable in future steps. Final sōngkō carries return semantics (B04 rn457777); not substituted merely with generic come.

## Reconciliation
- Crane lookup: 鹤, 白鹤, crane, white crane, 仙鹤, 鹤鸟 all zero. Bird niébī found but too broad to replace the crane species head; used as apposition, crane retained as minimal Chinese noun insertion.
- Wing: multiple forms found; selected B06 jiédā, keeping source pronunciation. Flight rá and ability bènsǐ were available but not selected: wings’ strength preserves the source image more directly. xiēqī came from 力气 expansion after 力量 zero; adopted in the text.
- Borrow/lend lú fits a transferable metaphor; ōng is specialized for tools and rejected. Recipient explicitly ngá bǒ.
- Far hxě + nie + kō paraphrases faraway place; a source-supported modifier construction, not an invented adjective expansion.
- Circuit concept shared budget 12 exact keys: 绕, 转圈, 围绕, 转, 绕行, 一圈, go round, 逛, 游玩, visit, 绕圈, around. yělǒ means turning round and round, not established as touring a location. zuān is a classifier, not a tour verb; rejected. zuán is intransitive turn; insufficient for circuit-of-place frame. zōu is nominal 周/around, lacking a complete frame establishing circling Litang. Consequently inserted minimal Chinese verb 绕 in the supported SOV frame instead of misusing a retrieved candidate.
- Proper name 理塘 queried once, zero; retained Chinese name, without inventing Tujia pronunciation.
- Borrowing remains visible in Chinese characters. These are productive proposed clauses; complete lines are not attested quotations.

The final text was checked once for source coverage, participants, semantic scope, head/modifier linkage, retrieved-candidate use, and source-linked spelling. No PDF generated, per task management instruction.
